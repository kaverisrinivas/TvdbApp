package com.example.loginshine

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.loginshine.model.LoginData
import com.example.loginshine.remote.GetDataService
import com.example.loginshine.model.Login
import com.example.loginshine.remote.RetrofitClientInstance
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChildActivity() : AppCompatActivity() {
    private var editText: EditText?=null
    var editText1: EditText?=null
    var loginbutton:Button?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editText = findViewById<EditText>(R.id.edit_text)
        editText1 = findViewById<EditText>(R.id.edit_text2)
        loginbutton = findViewById<Button>(R.id.login_button)
        loginbutton?.setOnClickListener {
            val login = Login("D1A80256-47F6-4F14-ADB5-70554C830688", "kaveri gajula", "5DD4CF538ACEF0.78327665")
            val service = RetrofitClientInstance.getRetrofit()?.create(GetDataService::class.java)
            val call = service?.createLogin(login)
            call?.enqueue(object : Callback<LoginData> {
                override fun onResponse(call: Call<LoginData>, response: Response<LoginData>) {
                    Toast.makeText(applicationContext, "successful" + response.body()?.token, Toast.LENGTH_LONG).show()
                    Log.d("token", response.body()?.token ?: "")
                }

                override fun onFailure(call: Call<LoginData>, t: Throwable) {
                    Toast.makeText(this@ChildActivity, "something wrong", Toast.LENGTH_LONG).show()
                }
            })
        }
    }
}
