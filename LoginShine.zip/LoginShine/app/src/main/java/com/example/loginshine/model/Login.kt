package com.example.loginshine.model

data class Login (
    private var apikey:String?=null,
    private var username:String?=null,
    private var userkey:String?=null)



