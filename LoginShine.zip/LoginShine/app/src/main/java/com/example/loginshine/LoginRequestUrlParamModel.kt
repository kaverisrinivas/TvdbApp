package com.example.loginshine

data class LoginRequestUrlParamModel(
        var params:HashMap<String,Int> ){

}
