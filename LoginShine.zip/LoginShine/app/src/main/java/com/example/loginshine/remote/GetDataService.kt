package com.example.loginshine.remote

import com.example.loginshine.model.EpisodeData
import com.example.loginshine.model.Login
import com.example.loginshine.model.LoginData
import retrofit2.Call
import retrofit2.http.*

interface GetDataService {

    @POST("/login")
    fun createLogin(@Body login: Login): Call<LoginData>
    @GET("/refresh_token")
    fun createtoken(): Call<LoginData>
    @GET("GET /episodes/{id}")
    fun episodeList(@Path ("id") pathId: Int): Call<EpisodeData>



}