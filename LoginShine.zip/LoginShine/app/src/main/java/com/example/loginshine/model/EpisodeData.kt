package com.example.loginshine.model

import com.google.gson.annotations.SerializedName

data class EpisodeData(
        @SerializedName ("absoluteNumber")
        var absoluteNumber:Int?=null,
        @SerializedName("airedEpisodeNumber")
        var airedEpisodeNumber:Int?=null,
        @SerializedName("airedSeason")
        var airedSeason:Int?=null,
        @SerializedName("airsAfterSeason")
        var airsAfterSeason:Int?=null,
        @SerializedName ("airsBeforeEpisode")
        var airsBeforeEpisode:Int?=null,
        @SerializedName("airsBeforeSeason")
        var airsBeforeSeason:Int?=null,
        @SerializedName("director")
        var director:String?=null,
        @SerializedName("directors")
        var directors:List<String>?=null


)
