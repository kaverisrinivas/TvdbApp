package com.example.loginshine.adapters

class EpisodeAdapter {

}